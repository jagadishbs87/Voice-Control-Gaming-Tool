// Modern Profile Modal and Tab Navigation for games.html

document.addEventListener('DOMContentLoaded', function() {
  // Profile Modal Logic
  (function() {
    const icon = document.getElementById('user-profile-icon');
    const modal = document.getElementById('user-profile-modal');
    const usernameDiv = document.getElementById('profile-username');
    const statsTableBody = document.querySelector('#profile-stats-table tbody');
    const avatarImg = document.getElementById('profile-avatar');
    const avatarUpload = document.getElementById('avatar-upload');
    const avatarUploadBtn = document.getElementById('avatar-upload-btn');
    const editUsernameInput = document.getElementById('edit-username-input');
    const editUsernameBtn = document.getElementById('edit-username-btn');
    const recentScoresTableBody = document.querySelector('#recent-scores-table tbody');
    const leaderboardGameSelect = document.getElementById('leaderboard-game-select');
    const leaderboardTableBody = document.getElementById('leaderboard-table-body');
    let currentUsername = localStorage.getItem('username') || '';
    let isLoading = false;

    if (!icon || !modal) return;

    // Open modal
    icon.onclick = function() {
      let username = localStorage.getItem('username');
      if (!username) {
        username = prompt('Enter your name to view your profile:');
        if (username) localStorage.setItem('username', username);
      }
      if (!username) return;
      currentUsername = username;
      fetchProfile(username);
      modal.style.display = 'flex';
    };

    // Close modal
    modal.addEventListener('click', function(e) {
      if (e.target === modal) modal.style.display = 'none';
    });
    document.querySelectorAll('.close-btn').forEach(btn => {
      btn.onclick = () => { modal.style.display = 'none'; };
    });

    // Fetch and render profile
    function fetchProfile(username) {
      isLoading = true;
      usernameDiv.textContent = 'Username: ' + username;
      statsTableBody.innerHTML = '<tr><td colspan="3">Loading...</td></tr>';
      avatarImg.src = 'https://cdn-icons-png.flaticon.com/512/149/149071.png';
      recentScoresTableBody.innerHTML = '';
      leaderboardGameSelect.innerHTML = '';
      leaderboardTableBody.innerHTML = '';
      fetch('http://localhost:3001/api/user-profile?username=' + encodeURIComponent(username))
        .then(res => res.json())
        .then(data => {
          // Avatar
          if (data.avatar) {
            avatarImg.src = 'data:image/png;base64,' + data.avatar;
          }
          // Username
          usernameDiv.textContent = 'Username: ' + data.username;
          editUsernameInput.value = data.username;
          // Stats
          if (!Array.isArray(data.stats) || data.stats.length === 0) {
            statsTableBody.innerHTML = '<tr><td colspan="3">No stats found.</td></tr>';
          } else {
            statsTableBody.innerHTML = data.stats.map(row =>
              `<tr><td>${row.game}</td><td>${row.times_played}</td><td>${row.highest_score}</td></tr>`
            ).join('');
          }
          // Recent scores
          if (Array.isArray(data.recent) && data.recent.length > 0) {
            recentScoresTableBody.innerHTML = data.recent.map(row =>
              `<tr><td>${row.game}</td><td>${row.score}</td><td>${new Date(row.created_at).toLocaleString()}</td></tr>`
            ).join('');
          } else {
            recentScoresTableBody.innerHTML = '<tr><td colspan="3">No recent scores.</td></tr>';
          }
          // Leaderboard game select
          leaderboardGameSelect.innerHTML = '';
          if (Array.isArray(data.stats)) {
            data.stats.forEach(row => {
              const opt = document.createElement('option');
              opt.value = row.game;
              opt.textContent = row.game;
              leaderboardGameSelect.appendChild(opt);
            });
          }
          if (leaderboardGameSelect.options.length > 0) {
            fetchLeaderboard(leaderboardGameSelect.value);
          } else {
            leaderboardTableBody.innerHTML = '<tr><td colspan="2">No leaderboard data.</td></tr>';
          }
        })
        .catch(err => {
          statsTableBody.innerHTML = '<tr><td colspan="3">Error loading stats.</td></tr>';
          recentScoresTableBody.innerHTML = '<tr><td colspan="3">Error.</td></tr>';
          leaderboardTableBody.innerHTML = '<tr><td colspan="2">Error.</td></tr>';
        })
        .finally(() => { isLoading = false; });
    }

    // Avatar upload logic
    avatarUploadBtn.onclick = function() {
      avatarUpload.click();
    };
    avatarImg.onclick = function() {
      avatarUpload.click();
    };
    avatarUpload.onchange = function() {
      const file = avatarUpload.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append('avatar', file);
      formData.append('username', currentUsername);
      avatarUploadBtn.disabled = true;
      fetch('http://localhost:3001/api/user/avatar', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) fetchProfile(currentUsername);
        else alert('Failed to upload avatar.');
      })
      .catch(() => alert('Failed to upload avatar.'))
      .finally(() => { avatarUploadBtn.disabled = false; });
    };

    // Username editing logic
    editUsernameBtn.onclick = function() {
      const newUsername = editUsernameInput.value.trim();
      if (!newUsername || newUsername === currentUsername) return;
      editUsernameBtn.disabled = true;
      fetch('http://localhost:3001/api/user/username', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ oldUsername: currentUsername, newUsername })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          localStorage.setItem('username', newUsername);
          currentUsername = newUsername;
          fetchProfile(newUsername);
        } else {
          alert('Failed to update username.');
        }
      })
      .catch(() => alert('Failed to update username.'))
      .finally(() => { editUsernameBtn.disabled = false; });
    };

    // Leaderboard game select logic
    leaderboardGameSelect.onchange = function() {
      fetchLeaderboard(leaderboardGameSelect.value);
    };

    // Fetch and render leaderboard
    function fetchLeaderboard(game) {
      leaderboardTableBody.innerHTML = '<tr><td colspan="2">Loading...</td></tr>';
      fetch('http://localhost:3001/api/leaderboard?game=' + encodeURIComponent(game))
        .then(res => res.json())
        .then(data => {
          if (!Array.isArray(data) || data.length === 0) {
            leaderboardTableBody.innerHTML = '<tr><td colspan="2">No data.</td></tr>';
          } else {
            const currentUser = localStorage.getItem('username');
            leaderboardTableBody.innerHTML = data.map((row, i) => {
              let badge = '';
              if (i === 0) badge = '<span class="badge gold">🥇</span>';
              else if (i === 1) badge = '<span class="badge silver">🥈</span>';
              else if (i === 2) badge = '<span class="badge bronze">🥉</span>';
              const highlight = row.username === currentUser ? ' class="current-user"' : '';
              return `<tr${highlight}><td>${badge}${row.username}</td><td>${row.highest_score}</td></tr>`;
            }).join('');
          }
        })
        .catch(() => {
          leaderboardTableBody.innerHTML = '<tr><td colspan="2">Error.</td></tr>';
        });
    }
  })();

  // Tab navigation for games.html
  (function() {
    const tabSnake = document.getElementById('tab-snake');
    const tabFlag = document.getElementById('tab-flag');
    const tabSudoku = document.getElementById('tab-sudoku');
    const snakeTab = document.getElementById('snake-tab');
    const flagTab = document.getElementById('flag-tab');
    const sudokuTab = document.getElementById('sudoku-tab');
    if (!tabSnake || !tabFlag || !tabSudoku) return;
    function showTab(tab) {
      [snakeTab, flagTab, sudokuTab].forEach(t => t.classList.remove('active'));
      [tabSnake, tabFlag, tabSudoku].forEach(b => b.classList.remove('active'));
      if (tab === 'snake') {
        snakeTab.classList.add('active');
        tabSnake.classList.add('active');
      } else if (tab === 'flag') {
        flagTab.classList.add('active');
        tabFlag.classList.add('active');
      } else if (tab === 'sudoku') {
        sudokuTab.classList.add('active');
        tabSudoku.classList.add('active');
      }
    }
    tabSnake.onclick = () => showTab('snake');
    tabFlag.onclick = () => showTab('flag');
    tabSudoku.onclick = () => showTab('sudoku');
  })();
}); 