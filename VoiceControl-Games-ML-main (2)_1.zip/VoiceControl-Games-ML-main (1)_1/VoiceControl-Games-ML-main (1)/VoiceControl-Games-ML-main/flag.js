// List of countries to randomly pick the correct flag and generate options
const countries = [
  "Argentina","Australia","Austria","Belgum","Canada",
  "Chile","Cuba","Finland","Greece","Ghana","Hungary",
  "Israel","Japan","Nepal","Pakistan","Sweden","Vietnam",
  "Zimbabwe","Brazil", "China", "Denmark", "Egypt", "England",
  "France", "India", "Italy", "Jordan", "Kenya","USA",
  "Mexico", "Norway", "Portugal", "Russia", "Turkey", "Ukraine",
];
let allOptions; // Variable to hold the shuffled options (correct and incorrect)
let score = 0;
let rounds = 0;
let sessionCountries = [];
let sessionIndex = 0;
game(); // Start the flag guessing game

function game() {
  if (rounds >= 10 || sessionIndex >= sessionCountries.length) {
    if (typeof saveGameScore === 'function') {
      saveGameScore('Flag', score);
    }
    alert('Game over! Your score: ' + score);
    showRestartButton();
    return;
  }
  // Clear the main flag display and the options section
  document.getElementById("main").innerHTML = "";
  document.getElementById("optionSetion").innerHTML = "";

  // Select the next flag from the shuffled sessionCountries
  let correctFlagNamae = sessionCountries[sessionIndex];
  sessionIndex++;
  allOptions = [correctFlagNamae]; // Initialize options array with the correct flag name

  // Add 3 additional random (but not duplicate) countries to the options array
  let distractors = countries.filter(c => c !== correctFlagNamae);
  shuffleArray(distractors);
  for (let i = 0; i < 3; i++) {
    allOptions.push(distractors[i]);
  }
  shuffleArray(allOptions); // Shuffle the options array

  // Create an image element to display the correct flag
  let correctFlag = document.createElement("img");
  correctFlag.src = `images/${correctFlagNamae}.png`;
  document.getElementById("main").appendChild(correctFlag);

  // Create a clickable option for each country in the shuffled options
  allOptions.forEach((element) => {
    let option = document.createElement("div");
    option.textContent = element;
    option.id = element;
    option.classList.add("option");
    document.getElementById("optionSetion").appendChild(option);
  });

  // Add click event listeners to each option
  let options = document.querySelectorAll(".option");
  options.forEach((option) => {
    option.addEventListener("click", () => {
      rounds++;
      if (option.textContent === correctFlagNamae) {
        option.classList.add("correctOption");
        score++;
        setTimeout(() => game(), 1000);
      } else {
        option.classList.add("incorrectOption");
        setTimeout(() => document.getElementById(`${correctFlagNamae}`).classList.add("correctOption"), 1000);
        setTimeout(() => game(), 1500);
      }
    });
  });
}

function showRestartButton() {
  let btn = document.getElementById('restart-flag-btn');
  if (!btn) {
    btn = document.createElement('button');
    btn.id = 'restart-flag-btn';
    btn.textContent = 'Restart';
    btn.style.position = 'absolute';
    btn.style.top = '20px';
    btn.style.left = '50%';
    btn.style.transform = 'translateX(-50%)';
    btn.style.zIndex = 1000;
    document.body.appendChild(btn);
  }
  btn.style.display = 'block';
  btn.onclick = function() {
    btn.style.display = 'none';
    startSession();
  };
}

//----------------------------------------------------------------
// Initialize voice recognition model
init();

function saveGameScore(game, score) {
  let username = localStorage.getItem('username');
  if (!username) {
    username = prompt('Enter your name to save your score:');
    if (username) localStorage.setItem('username', username);
  }
  if (!username) return; // User cancelled
  fetch('http://localhost:3001/api/scores', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, game, score })
  })
  .then(res => res.json())
  .then(data => console.log('Score saved:', data))
  .catch(err => console.error('Error saving score:', err));
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function startSession() {
  score = 0;
  rounds = 0;
  sessionCountries = countries.slice();
  shuffleArray(sessionCountries);
  sessionIndex = 0;
  document.getElementById('restart-flag-btn')?.remove();
  game();
}

//----------------------------------------------------------------
// Initialize voice recognition model
async function createModel() {
  const URL = "https://teachablemachine.withgoogle.com/models/XnLAQWwNO/";
  const checkpointURL = URL + "model.json"; // URL to the model JSON
  const metadataURL = URL + "metadata.json"; // URL to the metadata JSON

  const recognizer = speechCommands.create(
    "BROWSER_FFT", // FFT type for browser-based processing
    undefined,
    checkpointURL,
    metadataURL
  );

  // Ensure the model is loaded before using
  await recognizer.ensureModelLoaded();
  return recognizer; // Return the loaded recognizer
}

async function init() {
  const recognizer = await createModel(); // Load the recognizer model
  const classLabels = recognizer.wordLabels(); // Get the class labels from the model
  const labelContainer = document.getElementById("names"); // Container for displaying labels
 

  // Start listening for voice commands
  recognizer.listen(
    (result) => {
      const scores = result.scores; // Probability scores for each label
      for (let i = 0; i < classLabels.length; i++) {
        console.log(classLabels[i], result.scores[i]); // Log label probabilities

        // Normalize label and option IDs for matching
        const normalizedLabel = classLabels[i].toLowerCase().replace(/\s+/g, '');
        allOptions.forEach(option => {
          const normalizedOption = option.toLowerCase().replace(/\s+/g, '');
          if (normalizedLabel === normalizedOption && scores[i] > 0.45) {
            const clickableElement = document.getElementById(option);
            if (clickableElement) {
              clickableElement.click();
            }
          }
        });
      }
    },
    {
      includeSpectrogram: true, // Option to include spectrogram data in results
      probabilityThreshold: 0.1, // Minimum probability threshold for detection
      invokeCallbackOnNoiseAndUnknown: true, // Allow callback on unknown/noisy inputs
      overlapFactor: 0.1, // Overlap factor for continuous listening
    }
  );
}


