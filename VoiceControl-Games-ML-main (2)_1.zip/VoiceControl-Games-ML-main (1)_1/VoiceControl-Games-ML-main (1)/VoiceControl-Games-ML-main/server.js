const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });

const app = express();
app.use(cors());
app.use(express.json());

// Update these values with your MySQL credentials
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'jaga@87',
  database: 'game_scores'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

// Ensure users table exists and migrate existing scores
function migrateUsersTable() {
  db.query(`CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    avatar TEXT
  )`, (err) => {
    if (err) throw err;
    db.query('ALTER TABLE scores ADD COLUMN IF NOT EXISTS user_id INT', () => {
      // Ignore error if already exists
      db.query('SELECT DISTINCT username FROM scores', (err, users) => {
        if (err) throw err;
        users.forEach(u => {
          db.query('INSERT IGNORE INTO users (username) VALUES (?)', [u.username], () => {
            db.query('UPDATE scores SET user_id = (SELECT id FROM users WHERE username = ?) WHERE username = ?', [u.username, u.username]);
          });
        });
      });
    });
  });
}
migrateUsersTable();

// Save score endpoint
app.post('/api/scores', (req, res) => {
  const { username, game, score } = req.body;
  db.query(
    'INSERT INTO scores (username, game, score, created_at) VALUES (?, ?, ?, NOW())',
    [username, game, score],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ success: true, id: result.insertId });
    }
  );
});

// Get top 10 scores endpoint
app.get('/api/scores', (req, res) => {
  db.query('SELECT * FROM scores ORDER BY score DESC LIMIT 10', (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

// Save or update avatar (robust: create user if not exists, with logging)
app.post('/api/user/avatar', upload.single('avatar'), (req, res) => {
  const { username } = req.body;
  if (!username || !req.file) {
    console.error('Avatar upload: Missing username or file');
    return res.status(400).json({ error: 'Username and avatar required' });
  }
  const avatar = req.file.buffer.toString('base64');
  db.query('INSERT IGNORE INTO users (username) VALUES (?)', [username], (err) => {
    if (err) {
      console.error('Avatar upload: Failed to ensure user exists', err);
      return res.status(500).json({ error: 'Failed to ensure user exists' });
    }
    db.query('UPDATE users SET avatar = ? WHERE username = ?', [avatar, username], (err2) => {
      if (err2) {
        console.error('Avatar upload: Failed to update avatar', err2);
        return res.status(500).json({ error: 'Failed to update avatar' });
      }
      res.json({ success: true });
    });
  });
});

// Get user profile (with avatar, stats, recent scores)
app.get('/api/user-profile', (req, res) => {
  const { username } = req.query;
  if (!username) return res.status(400).json({ error: 'Username is required' });
  db.query('SELECT * FROM users WHERE username = ?', [username], (err, users) => {
    if (err || users.length === 0) return res.status(404).json({ error: 'User not found' });
    const user = users[0];
    db.query(
      `SELECT game, COUNT(*) as times_played, MAX(score) as highest_score
       FROM scores WHERE username = ? GROUP BY game`,
      [username],
      (err, stats) => {
        if (err) return res.status(500).json({ error: err });
        db.query(
          'SELECT game, score, created_at FROM scores WHERE username = ? ORDER BY created_at DESC LIMIT 10',
          [username],
          (err, recent) => {
            if (err) return res.status(500).json({ error: err });
            res.json({
              username: user.username,
              avatar: user.avatar,
              stats,
              recent
            });
          }
        );
      }
    );
  });
});

// Update username (robust: check for unique, update both users and scores, with logging)
app.post('/api/user/username', (req, res) => {
  const { oldUsername, newUsername } = req.body;
  if (!oldUsername || !newUsername) {
    console.error('Username change: Both usernames required');
    return res.status(400).json({ error: 'Both usernames required' });
  }
  if (oldUsername === newUsername) return res.json({ success: true });
  db.query('SELECT id FROM users WHERE username = ?', [newUsername], (err, rows) => {
    if (err) {
      console.error('Username change: Database error', err);
      return res.status(500).json({ error: 'Database error' });
    }
    if (rows.length > 0) {
      console.error('Username change: Username already taken');
      return res.status(409).json({ error: 'Username already taken' });
    }
    db.query('UPDATE users SET username = ? WHERE username = ?', [newUsername, oldUsername], (err2) => {
      if (err2) {
        console.error('Username change: Failed to update username in users', err2);
        return res.status(500).json({ error: 'Failed to update username in users' });
      }
      db.query('UPDATE scores SET username = ? WHERE username = ?', [newUsername, oldUsername], (err3) => {
        if (err3) {
          console.error('Username change: Failed to update username in scores', err3);
          return res.status(500).json({ error: 'Failed to update username in scores' });
        }
        res.json({ success: true });
      });
    });
  });
});

// Leaderboard for a game
app.get('/api/leaderboard', (req, res) => {
  const { game } = req.query;
  if (!game) return res.status(400).json({ error: 'Game is required' });
  db.query(
    `SELECT username, MAX(score) as highest_score
     FROM scores WHERE game = ?
     GROUP BY username
     ORDER BY highest_score DESC
     LIMIT 10`,
    [game],
    (err, results) => {
      if (err) return res.status(500).json({ error: err });
      res.json(results);
    }
  );
});

app.listen(3001, () => console.log('Server running on port 3001')); 
